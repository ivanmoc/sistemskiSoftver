#pragma once
#include <string>
using namespace std;

class RelocationRecord
{
public:
	int offset;
	string type;
	int ordValue;
	string name;

	RelocationRecord(int off, string ty, int ord);
	RelocationRecord(string name);
	~RelocationRecord();

	void writeRecToFile(ofstream& myfile);
};


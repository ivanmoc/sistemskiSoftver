#pragma once
#include<string>

using namespace std;

class Symbol
{
public:
	Symbol();
	void setLenght(int lenght);
	~Symbol();
	static int ID;

	Symbol(string ttype, string nname, int ssectionNumber, int ooffset, int llenght, char fflag) {
		type = ttype;
		this->number = ID++;
		name = nname;
		sectionNumber = ssectionNumber;
		offset = ooffset;
		lenght = llenght;
		flag = fflag;
	}

	string type="";
	int number=0;
	string name="";
	int sectionNumber=0;
	int offset=0;
	int lenght=0;
	char flag ='u';
	

	void writeToFile(ofstream& myfile);
};


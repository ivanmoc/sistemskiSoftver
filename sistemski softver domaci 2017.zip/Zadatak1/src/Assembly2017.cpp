
#include "FileParser.h"


int main(int argc, char **argv)
{
	FileParser* fileParser = new FileParser(argv[1],argv[2]);
	fileParser->firstPass();
	fileParser->writeToFile();
	fileParser->secondPass();
    return 0;
}


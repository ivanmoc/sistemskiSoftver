
#include "TableOfSymbols.h"



TableOfSymbols::TableOfSymbols()
{
	vector<Symbol> niz = vector<Symbol>();
}


void TableOfSymbols::writeToFile(ofstream& myfile) {
	for (list<Symbol>::const_iterator ci = listObject.begin(); ci != listObject.end(); ++ci) {
		myfile << "-----------------#Tabela Simbola--------------------" << "/n";

	}
}
	

TableOfSymbols::~TableOfSymbols()
{
	//destroy list of ints
}


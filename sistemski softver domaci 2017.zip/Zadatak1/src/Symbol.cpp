
#include "Symbol.h"
#include "fstream"

int Symbol::ID = 0;

Symbol::Symbol()
{
}

void Symbol::setLenght(int lenght) {
	this->lenght = lenght;
}

void Symbol :: writeToFile(ofstream& myfile) {
	string padding;
	int difference = 10 - this->name.length();
	if (difference > 0) {
		for (int i = 0; i < difference; i++) padding = padding + " ";
	}
	myfile << this->type << "      " << this->number << "   " << this->name << padding << "     " << this->sectionNumber  << "      " << this->offset << "      " << this->lenght << "      " << this->flag << "\n";
}

string type = "";
string name = "";
int sectionNumber = 0;
int offset = 0;
int lenght = 0;
char flag = 'u';

Symbol::~Symbol()
{
}

#pragma once
#include<string>
#include <vector>
using namespace std;

class LineParser
{
public:
	LineParser();
	~LineParser();

	string getLabel(string line);
	string getDirective(string line);
	string getSection(string line);
	string getInstrucion(string line);
	vector<string> tokenizeLine(string Line);
	vector<string> getGlobal(string Line);

	void firstPass();


};


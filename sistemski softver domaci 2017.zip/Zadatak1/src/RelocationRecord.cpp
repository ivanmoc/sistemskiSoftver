
#include "RelocationRecord.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <iomanip>

RelocationRecord::RelocationRecord(int off, string ty, int ord) 
{
	offset = off;
	type = ty;
	ordValue = ord;
	name = "";
}

RelocationRecord::RelocationRecord(string nname)
{
	name = nname;
}

void RelocationRecord::writeRecToFile(ofstream& myfile)
{
	if (name != "") {
		myfile << "\n";
		myfile << name << "\n";
		myfile << "Ofset   " << "    Tip" << "    vrednost  " << "\n";
	}
	else {
		myfile << hex << std::setw(8) << std::setfill('0') << offset << "    " << type << "      " << ordValue << "     " << "\n";
	} 
}

RelocationRecord::~RelocationRecord()
{
}

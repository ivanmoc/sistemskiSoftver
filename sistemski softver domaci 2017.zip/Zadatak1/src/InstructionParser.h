#pragma once
#include<unordered_map>
#include <string>
#include <vector>

using namespace std;

class InstructionParser
{
public:
	InstructionParser();
	~InstructionParser();

	string getAddressingType(string line);
	vector<string> tokenizeInstruction(string line);
	string getInstructionName(string line);
	int getInstructionSize(string line);
	string cutLabel(string line);
	string cutName(string line);
	bool isRelativeInstruction(string line);


	static unordered_map<string, int>* addressHash;
	static unordered_map<string, int>* instructionHash;
	static unordered_map<string, int>* registerHash;
	
};


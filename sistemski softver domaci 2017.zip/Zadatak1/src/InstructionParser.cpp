
#include "InstructionParser.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <unordered_map>

using namespace std;

unordered_map<string, int>* InstructionParser:: addressHash;
unordered_map<string, int>* InstructionParser::instructionHash;
unordered_map<string, int>* InstructionParser::registerHash;

string PCrelativeInstructions[10] = { "INT","JMP","CALL", "RET", "JZ", "JNZ", "JGZ", "JGEL", "JLZ", "JLEZ" };

bool InstructionParser::isRelativeInstruction(string line) {
	bool result = false;
	int a = PCrelativeInstructions->length();
	for (int i = 0; i < 10; i++) {
		if (line == PCrelativeInstructions[i]) {
			result = true;
			return result;
		}
	}
	return result;
}

InstructionParser::InstructionParser()
{
    addressHash = new unordered_map<string, int>();
	addressHash->insert(pair<string, int>("imm", 0x04));
	addressHash->insert(pair<string, int>("regDir", 0x00));
	addressHash->insert(pair<string, int>("regIndir", 0x02));
	addressHash->insert(pair<string, int>("memDir", 0x06));
	addressHash->insert(pair<string, int>("regIndirDisp", 0x07));

	registerHash = new unordered_map<string, int>();
	registerHash->insert(pair<string, int>("R0", 0x00));
	registerHash->insert(pair<string, int>("R1", 0x01));
	registerHash->insert(pair<string, int>("R2", 0x02));
	registerHash->insert(pair<string, int>("R3", 0x03));
	registerHash->insert(pair<string, int>("R4", 0x04));
	registerHash->insert(pair<string, int>("R5", 0x05));
	registerHash->insert(pair<string, int>("R6", 0x06));
	registerHash->insert(pair<string, int>("R7", 0x07));
	registerHash->insert(pair<string, int>("R8", 0x08));
	registerHash->insert(pair<string, int>("R9", 0x09));
	registerHash->insert(pair<string, int>("R10",0x0A));
	registerHash->insert(pair<string, int>("R12",0x0B));
	registerHash->insert(pair<string, int>("R11",0x0C));
	registerHash->insert(pair<string, int>("R13",0x0D));
	registerHash->insert(pair<string, int>("R14",0x0E));
	registerHash->insert(pair<string, int>("R15",0x0F));

	registerHash->insert(pair<string, int>("SP", 0x10));
	registerHash->insert(pair<string, int>("PC", 0x11));

    instructionHash = new unordered_map<string, int>();
	instructionHash->insert(pair<string, int>("INT", 0x00));
	instructionHash->insert(pair<string, int>("JMP", 0x02));
	instructionHash->insert(pair<string, int>("CALL", 0x03));
	instructionHash->insert(pair<string, int>("RET", 0x01));
	instructionHash->insert(pair<string, int>("JZ", 0x04));
	instructionHash->insert(pair<string, int>("JNZ", 0x05));
	instructionHash->insert(pair<string, int>("JGZ", 0x06));
	instructionHash->insert(pair<string, int>("JGEZ", 0x07));
	instructionHash->insert(pair<string, int>("JLZ", 0x08));
	instructionHash->insert(pair<string, int>("JLEZ", 0x09)); //ZA KONTROLU TOKA

	instructionHash->insert(pair<string, int>("LOAD", 0x10));
	instructionHash->insert(pair<string, int>("LOADUB", 0x10));
	instructionHash->insert(pair<string, int>("LOADSB", 0x10));
	instructionHash->insert(pair<string, int>("STORE", 0x11));  //LOAD STORE INST
	instructionHash->insert(pair<string, int>("STOREB", 0x11));
	instructionHash->insert(pair<string, int>("STOREW", 0x11));

	instructionHash->insert(pair<string, int>("PUSH", 0x20));
	instructionHash->insert(pair<string, int>("POP", 0x21));  //ZA RAD SA STEKOM

	instructionHash->insert(pair<string, int>("ADD", 0x20));
	instructionHash->insert(pair<string, int>("SUB", 0x20));
	instructionHash->insert(pair<string, int>("MUL", 0x21));
	instructionHash->insert(pair<string, int>("DIV", 0x22));
	instructionHash->insert(pair<string, int>("MOD", 0x23));
	instructionHash->insert(pair<string, int>("AND", 0x24));
	instructionHash->insert(pair<string, int>("OR", 0x25));
	instructionHash->insert(pair<string, int>("XOR", 0x24));
	instructionHash->insert(pair<string, int>("NOT", 0x25));
	instructionHash->insert(pair<string, int>("AND", 0x26));
	instructionHash->insert(pair<string, int>("ASR", 0x26));  //ARITM LOG INSTR.

}

string InstructionParser::getAddressingType(string line) {
	line = cutLabel(line);
	line = cutName(line);
	string segment;
	vector<std::string> seglist;
	bool hasRegister = false;
	size_t registerCount=0;

	std::stringstream ss(line);
	while (std::getline(ss, segment, ',')) seglist.push_back(segment);

	int addCodes[3] = { 0,0,0 };
	string chars[5] = { "R","r","SP","PC" };

	for (int i = 0; i < seglist.size(); i++) {
		string curr = seglist.at(i);

		for (int i = 0; i < chars->length(); i++) {
			if (curr.find(chars[i]) != string::npos) {
				hasRegister = true;
				registerCount++;
			}
			else hasRegister = false;
			if (curr.find("$") != string::npos) return "regIndirDisp";

			if (curr.find("[") != string::npos) {
				if ((curr.find("+") != string::npos) && hasRegister) return "regIndirDisp";
				else return "regIndir";
			}

			if (line.find("#") != string::npos) {
				return "imm";
			}
		}
	}
	if (registerCount == seglist.size()) return "regDir";
	else return "memDir";
}



int InstructionParser::getInstructionSize(string line) {
	if (line == "regDir" || line == "regIndir") return 4;
	else if (line == "regIndirDisp" || line == "imm" || line == "memDir") return 8;
	else return -1;	
}

vector<string> InstructionParser:: tokenizeInstruction(string line)
{
	line = InstructionParser::cutLabel(line);
	line = InstructionParser::cutName(line);
	string segment;
	vector<std::string> seglist;
	int start;
	std::stringstream ss(line);
	while (std::getline(ss, segment, ','))
	{
		segment.erase(std::remove(segment.begin(), segment.end(), ('[', ']', ' ','	', '$', '#', '+', '-','	')), segment.end());
		segment.erase(std::remove(segment.begin(), segment.end(), '#'), segment.end());
		segment.erase(std::remove(segment.begin(), segment.end(), '$'), segment.end());
		segment.erase(std::remove(segment.begin(), segment.end(), '['), segment.end());
		segment.erase(std::remove(segment.begin(), segment.end(), ']'), segment.end());
		if (segment.find_first_of("+") != string::npos) {
			string segPart;
			std::stringstream sstream(segment);
			while (std::getline(sstream, segPart, '+')) seglist.push_back(segPart);
			continue;
		}
		seglist.push_back(segment);
	}
	return seglist;
}

string InstructionParser::getInstructionName(string line)
{
	line = cutLabel(line);
	if (line == "") return "labelOnly";
	int start = line.find_first_not_of(" ");
	line = line.substr(start, line.size());
	int end = line.find_first_of(" ");
	string name = line.substr(0, end);
	return name;
}

string InstructionParser::cutLabel(string line) {
	int labelPos = line.find_first_of(":");
	if (labelPos != string::npos) line = line.substr(labelPos+1, line.size());
	return line;
}

string InstructionParser::cutName(string line) {
	int namePos = line.find_first_not_of(" ");
	if (namePos != string::npos) line = line.substr(namePos, line.size());

	int endPos = line.find_first_of(" ");
	if (endPos != string::npos) line = line.substr(endPos,line.size());

	int start = line.find_first_not_of(" ");
	if ( start != string::npos) line = line.substr(start, line.size());

	return line;
}


InstructionParser::~InstructionParser()
{
}

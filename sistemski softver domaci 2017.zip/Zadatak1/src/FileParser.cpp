
#include "FileParser.h"
#include <string>
#include <list>
#include <algorithm>
#include<unordered_map>
#include <stdlib.h>
#include <ctype.h>
#include <iomanip>
#include <list>

using namespace std;

list<Symbol> FileParser:: listOfSymbols;
ofstream FileParser::myfile;
ifstream FileParser::infile;
list<RelocationRecord> FileParser::listOfRecs;
int FileParser::jumpAddress;
bool hasDirective = false;
bool relative = false;
bool pcRelative = false;
int calculatedValue = 0;

FileParser::FileParser(string in, string out)
{
    infile.clear();
	infile.seekg(0,ios::beg);

	FileParser::locationCounter = 0;
	currentSection = "";
	//ordinalNumber = 0;
	currSize = 0;
	flag = 'U';
	currentSectionNumber = -1;

	FileParser::myfile.open(out,std::ofstream::out);
	FileParser::infile.open(in,std::ifstream::out);
	

	ofstream myfile;
	
	
	LineParser* lineParser = new LineParser();
	InstructionParser* instructionParser = new InstructionParser();
	//TableOfSymbols* tableOfSymbols = new TableOfSymbols();
}

void FileParser::firstPass() {
	
	string line;
	string readValue = "";
	Symbol newSymbol;
	string oldSectionName = "";
	getline(infile, line);
	int orgValue = 0;
	int oldOrgValue = 0;
	
	while (line.find(".end") == string::npos)
	{
 		if(!line.empty() && line[line.size()-1] =='\r') line.erase(line.size()-1);
		
		if (line.empty()) {
			getline(FileParser::infile, line);
			continue;
		}

		if (line.find("ORG") != string::npos) {
			int start = line.find("x");
			string hex = line.substr(start + 1, line.length());
			int x = strtol(hex.c_str(), NULL, 16);

			//const char * c = hex.c_str();
			//orgValue = atoi(c);
			orgValue = x;
			getline(infile, line);
			continue;
		}
		int comment_position = line.find(";");
		if (comment_position != string::npos) { line = line.substr(0, comment_position); }
		readValue = lineParser->getSection(line);

		if (readValue != "") {
			currentSectionNumber++;
			for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
				if (ci->Symbol::name == oldSectionName) {
					ci->Symbol::lenght = FileParser::locationCounter - oldOrgValue;
					oldOrgValue = 0;
				}// setting the lenght for the section that has ended
			}  
			newSymbol = Symbol("SEC", readValue, currentSectionNumber, orgValue, 0, 'u');
			FileParser::listOfSymbols.push_back(newSymbol);
			locationCounter = orgValue;
			oldOrgValue = orgValue;
			orgValue = 0;
			oldSectionName = readValue; //
			getline(infile, line);
			continue;
		}

		readValue = lineParser->getLabel(line);
		if (readValue != "") {
			char flag = 'l';
			if (std::find(globalSymbols.begin(), globalSymbols.end(), readValue) != globalSymbols.end()) flag = 'g';
			newSymbol = Symbol("SYM", readValue, currentSectionNumber, locationCounter, 0, flag);
			FileParser::listOfSymbols.push_back(newSymbol);
		}

		string directive = lineParser->getDirective(line);
		if (directive != "") {
			if (directive == "DB") FileParser::locationCounter += 1; 
			if (directive == "DW") FileParser::locationCounter += 2; 
			if (directive == "DD") FileParser::locationCounter += 4; 
			getline(infile, line);
			continue;
		}

		string name = instructionParser->getInstructionName(line);
		if (name == "labelOnly") {
			getline(infile, line);
			continue;
		}

		string addrType = instructionParser->getAddressingType(line);
		int size = instructionParser->getInstructionSize(addrType);
		FileParser::locationCounter += size;

		vector<string> readValueForGlobal;
		readValueForGlobal = lineParser->getGlobal(line);
		if (!readValueForGlobal.empty()) {
			globalSymbols.insert(globalSymbols.end(), readValueForGlobal.begin(), readValueForGlobal.end()); 
		}
		getline(infile, line);
	}

	if (oldSectionName != "") {
		for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
			if (ci->Symbol::name == oldSectionName) ci->Symbol::lenght = FileParser::locationCounter - oldOrgValue;
		}  // setting the lenght for the section that has ended
	}

}

void FileParser::writeToFile() {
	
	//ofstream* myFilePointer = &myfile;
	myfile << "-----------------#Tabela Simbola--------------------" << "\n";
	myfile << "Tip    " << "r.b.  " << "ime        " << "r.b.sek   " << "poc.ad.  " << "vel.  " << "doseg " << "\n";
	for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
		ci->Symbol::writeToFile(myfile);

	}
}


void FileParser::writeRecToFile() {
	myfile << "\n" << "\n";
	myfile << "-----------------#Relokacioni zapisi--------------------" << "\n";
	for (list<RelocationRecord>::iterator ci = FileParser::listOfRecs.begin(); ci != listOfRecs.end(); ++ci) {
		ci->RelocationRecord::writeRecToFile(myfile);

	}
}


void FileParser::secondPass() {
	myfile << "\n \n \n";
	myfile << "-----------------#Sadrzaji sekcija--------------------" << "\n";
	FileParser::infile.clear();
	infile.seekg(0, infile.beg);

	FileParser::locationCounter = 0;
	currentSection = "";

	string line;
	string readValue = "";
	Symbol newSymbol;
	getline(FileParser::infile, line);
	string directiveLabel;

	while (line.find(".end") == string::npos)
	{   
   		if (!line.empty() && line[line.size() - 1] == '\r') line.erase(line.size() - 1);
		if (line.find("ORG")!=string::npos) {
			getline(FileParser::infile, line);
			continue;
		}
		if (line.find(".") != string::npos) {
			if (line.find("global") == string::npos) {
				myfile << "\n" << line << "\n";
				FileParser::listOfRecs.push_back("#rel" + line);
				FileParser::locationCounter = 0;
			}
			getline(FileParser::infile, line);
			continue;
		}
		if (line.empty()) {
			getline(FileParser::infile, line);
			continue;
		}
		readValue = lineParser->getSection(line);
		if (readValue != "") {
			currentSection = readValue;
			string recordName = "#rel" + readValue;
			RelocationRecord rec = RelocationRecord(recordName);
			FileParser::listOfRecs.push_back(rec);
			myfile << "\n";
		    FileParser::myfile << readValue << "\n";
			FileParser::locationCounter = 0;
			getline(FileParser::infile, line);
			continue;		 
		}
		if (lineParser->getDirective(line) == "") {
			hasDirective = false;
			string addType = instructionParser->getAddressingType(line);
			int size = instructionParser->getInstructionSize(addType);
			FileParser::locationCounter += size;
	    	readInstructions(line);
			getline(FileParser::infile, line);
			continue;
		}
		else {
			string name = instructionParser->getInstructionName(line);
			if (name == "ADD") {
				getline(FileParser::infile, line);
				continue;
			}
			hasDirective = true;
			bool plus = true;
			string directiveName = lineParser->getDirective(line);
			if ((line.find("+") != string::npos) || (line.find("-") != string::npos)) {
				directiveLabel = "";
				int pos = line.find_first_of("+");
				if (pos == string::npos) {
					pos = line.find_first_of("-");
					plus = false;
				}
				int first = 0;
				int second = 0;
				int pos1 = pos - 1;
				int pos2 = pos + 1;
				string label1 = string(1,line.at(pos1));
				string label2 = string(1, line.at(pos2));
				for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
					if (ci->Symbol::name == label1) first = ci->Symbol::offset;
					if (ci->Symbol::name == label2) second = ci->Symbol::offset;
				}
				if (plus) calculatedValue = second + first;
				else calculatedValue = first - second;
				
			}
			else {
				vector<string> tokenizedString = instructionParser->tokenizeInstruction(line);
				directiveLabel = tokenizedString[0];
			}
			readDirective(directiveName, directiveLabel);
		}
		getline(FileParser::infile, line);
		
	}
	writeRecToFile();
}

void FileParser::readDirective(string directiveName, string directiveLabel) {
	if (directiveLabel == "") {
		if (directiveName == "DB") myfile << hex << std::setw(2) << std::setfill('0') << calculatedValue << "\n";
		if (directiveName == "DW") myfile << hex << std::setw(4) << std::setfill('0') << reverseBytes16(calculatedValue) << "\n";
		if (directiveName == "DD") myfile << std::setw(8) << std::setfill('0') << reverseBytes32(calculatedValue) << "\n";
	}
	else {
		int embedded = labelAndRelocation(directiveLabel, true);
		if (directiveName == "DB") myfile << hex << std::setw(2) << std::setfill('0') << embedded << "\n";
		if (directiveName == "DW") myfile << hex << std::setw(4) << std::setfill('0') << reverseBytes16(embedded) << "\n";
		if (directiveName == "DD") myfile << std::setw(8) << std::setfill('0') << reverseBytes32(embedded) << "\n";
	}
}

int FileParser::reverseBytes32(int value) {
	int swapped;
	swapped = ((value >> 24) & 0xff) | // move byte 3 to byte 0
		((value << 8) & 0xff0000) | // move byte 1 to byte 2
		((value >> 8) & 0xff00) | // move byte 2 to byte 1
		((value << 24) & 0xff000000); // byte 0 to byte 3
	return swapped;
}

int FileParser::reverseBytes16(int value) {
	int swapped;
	swapped = ((value >> 8) | (value << 8));
	return swapped;
}


int FileParser::getDirectiveSize(string directiveName) {
	if (directiveName == "DB") return 2;
	if (directiveName == "DW") return 4;
	if (directiveName == "DD") return 8;
}

int FileParser::readInstructions(string line) {
		if (line.find(".") != string::npos) {
			return -1;
		}
		string name = instructionParser->getInstructionName(line);
		if (line.find("$") != string::npos) pcRelative = true;
	    relative = instructionParser->isRelativeInstruction(name);

		if (name == "labelOnly") return 0;
		unordered_map<std::string, int>::const_iterator got = InstructionParser::instructionHash->find(name);
		int opcode = got->second;
		int embedded;

		string addType = instructionParser->getAddressingType(line);

		got = InstructionParser::addressHash->find(addType);
		int addrCode = got->second;

		int regCodes[3] = { 0,0,0 };
	
		vector<string> tokenizedString = instructionParser->tokenizeInstruction(line);
		for (int i = 0; i < tokenizedString.size(); i++) {
			string currRegister = tokenizedString.at(i);
			if (InstructionParser::registerHash->count(currRegister)) {
				int code = InstructionParser::registerHash->at(currRegister);
				regCodes[i] = code;
			}
		}
		if ((addType == "regIndirDisp") && pcRelative) regCodes[1] = 0x11; //kod za PC

		
		for (int i = 0; i < tokenizedString.size(); i++) {
			if (((addType == "imm") || (addType == "regIndirDisp")) && (tokenizedString[i].find_first_not_of("0123456789") == string::npos)) {
				embedded = std::stoi(tokenizedString[i]);
				break;
			}
			if (!(InstructionParser::registerHash->count(tokenizedString[i]))) {
				//string string1 = tokenizedString[i].substr(0, tokenizedString[i].length() - 1);
				string string1 = tokenizedString[i].substr(0, tokenizedString[i].length());
				embedded = labelAndRelocation(string1 ,false);
				break;
			}			
			
		}

		//unsigned int result = (a << 24) | (b << 16) | (c << 8) | d;     sa stack overflow-a
		unsigned int result = 0;
		if ((addType == "regDir") || (addType == "regIndir")) {
			result = (opcode << 24 ) | (addrCode << 21) | regCodes[0] << 16 | regCodes[1] << 11 | regCodes[2] << 8;		
			myfile << hex << std::setw(8) << std::setfill('0') << result << "\n";
		}
		else {
			result = (opcode << 24) | (addrCode << 21) | regCodes[0] << 16 | regCodes[1] << 11 | regCodes[2] << 8;
			myfile << hex << std::setw(8) << std::setfill('0')<< result <<" ";
			result = embedded;	
			myfile << hex << std::setw(8) << std::setfill('0') << reverseBytes32(result) << "\n";
		}
		return result;
}

int FileParser::labelAndRelocation(string line, bool directive) {
	int returnValue;
	int offset = FileParser::locationCounter - 4;
	int embedded;
	string relocationType;
	int value; //redniBroj
	for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
		int sectionNumber = ci->Symbol::sectionNumber;
		string sectionName = findSectionName(sectionNumber);
		if (currentSection == sectionName && ci->Symbol::type == "SYM" && ci->Symbol::name == line) {
			jumpAddress = ci->Symbol::offset;
			embedded = jumpAddress - FileParser::locationCounter;
			return embedded;  /// nalaze se u istoj sekciji nema relokacije
		}
		if (ci->Symbol::name == line) {
			if (ci->Symbol::flag == 'g') {
				/*if (!directive) {
					relocationType = "rel";?
					embedded = -4; //ili -8?
				}
				else {
					relocationType = "aps";
					embedded = 0; 
					if (relative) embedded = -4;
					else embedded = 0;
					relative = false;
				} */
				if (relative) {
					relocationType = "rel";
					embedded = -4;
				}
				else {
					relocationType = "aps";
					embedded = 0;
				}

				if (pcRelative) {
					relocationType = "rel";  //poseban slucaj za pcRelativno adresiranje, jeste rel, ali instr nije rel..
				}

				pcRelative = false;

				value = ci->Symbol::number;
				if (directive) offset += 4;
				RelocationRecord rec = RelocationRecord(offset, relocationType, value);
				FileParser::listOfRecs.push_back(rec);  ///simbol je globalan 
				return embedded;
			    }

	
			if (ci->Symbol::flag == 'l') {
				/*if (!directive) {
					relocationType = "rel";
					value = ci->Symbol::number;
					embedded = ci->Symbol::offset - 4;
				}
				else {
					relocationType = "aps";
					value = ci->Symbol::sectionNumber;
					embedded = ci->Symbol::offset;
				} */
				if (relative) {
					relocationType = "rel";
					value = ci->Symbol::sectionNumber;
					embedded = ci->Symbol::offset - 4;
				}
				else {
					relocationType = "aps";
					value = ci->Symbol::sectionNumber;
					embedded = ci->Symbol::offset;
				}

				if (pcRelative) {
					relocationType = "rel";  //poseban slucaj za pcRelativno adresiranje, jeste rel, ali instr nije rel..
				}

				pcRelative = false;

				if (directive) offset += 4;
				RelocationRecord rec = RelocationRecord(offset, relocationType, value);
				FileParser::listOfRecs.push_back(rec);  ///simbol je globalan 
				return embedded;
			}
		}
	}	
}

string FileParser::findSectionName(int sectionNumber) {
	for (list<Symbol>::iterator ci = FileParser::listOfSymbols.begin(); ci != listOfSymbols.end(); ++ci) {
		if ((ci->Symbol::type == "SEC") && (ci->Symbol::sectionNumber == sectionNumber)) {
			jumpAddress = ci->Symbol::offset;
			return ci->Symbol::name;
		}
	}
}

FileParser::~FileParser()
{
}

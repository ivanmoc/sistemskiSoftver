
#include "LineParser.h"
#include <fstream>
#include <sstream>


LineParser::LineParser()
{
}

string LineParser::getLabel(string line) {
	string label = "";
	int position = line.find(':');
	int start = line.find_first_not_of(" \t\n"); //position of first non-space character
	if (position != string::npos) {
		 label = line.substr(start, position);
	}
	return label;
}

string LineParser::getSection(string line) {
	string sectionNames[] = { "text", "rodata", "bss", "data" };
	for (int i = 0; i < 4; i++) {
		int position;
		if ((position = line.find(sectionNames[i]) != string::npos)) {      //za sada radi samo ako je labela definisana na pocetku reda
			int endPosition = line.find_first_of(" \t\n");
			return line.substr(position, line.find(":"));
		}
	}
	return "";
}

string LineParser::getDirective(string line) {
	string directives[3] = { "DD","DB","DW" };
	for (int i = 0; i < (directives->length()+1); i++) {
		if (line.find(directives[i]) != string::npos) {
			return directives[i];
		}
	}
	return "";
}

vector<string> LineParser::tokenizeLine(string line)
{
	std::stringstream ss(line);
	std::string segment;
	std::vector<std::string> seglist;

	while (std::getline(ss, segment, ','))
	{
		seglist.push_back(segment);
	}
	return seglist;
}

vector<string> LineParser::getGlobal(string line) {
	vector<string> globalSymbols;
	int position = line.find("global");
	if (position != string::npos) {
		int startPosition = line.find("<") + 1;
		int endPosition = line.find(">");
		int number = endPosition - startPosition;
		string shortString = line.substr(startPosition, number);
	    globalSymbols = LineParser::tokenizeLine(shortString);
	}
	return globalSymbols;
}


LineParser::~LineParser()
{
}

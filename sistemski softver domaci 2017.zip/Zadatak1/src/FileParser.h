#pragma once
#include <fstream>
#include <sstream>
#include "LineParser.h"
#include "InstructionParser.h"
#include "Symbol.h"
#include "RelocationRecord.h"
#include <list>
class FileParser
{
public:
	FileParser(string in, string out);
	~FileParser();

	//TableOfSymbols* table;
	LineParser* lineParser;
	InstructionParser* instructionParser;
	//TableOfSymbols* tableOfSymbols;
	void firstPass();
	void secondPass();
	void writeToFile();
	int readInstructions(string line);
	void readDirective(string line, string line2);
	int reverseBytes16(int value);
	int getDirectiveSize(string line);
	int reverseBytes32(int value);

	void writeRecToFile();

	int labelAndRelocation(string line, bool directive);
	string findSectionName(int num);
	int findSecNum(string line);

	int locationCounter;
	string currentSection;
	int currentSectionNumber;
	int ordinalNumber;
	int currSize;
	char flag;
	static ofstream myfile;
	static ifstream infile;

	static list<Symbol> listOfSymbols;
	static list<RelocationRecord> listOfRecs;
	static int jumpAddress;
	vector<string> globalSymbols;
};


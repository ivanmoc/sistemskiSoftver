#pragma once
#include "Symbol.h"
#include <list>
#include <fstream>
#include <vector>

class TableOfSymbols
{
public:
	TableOfSymbols();
	~TableOfSymbols();

	void writeToFile(ofstream& myfile);

	static list<Symbol> listOfSymbols;
	list<Symbol> listObject;
	vector<Symbol> niz;
	

};

